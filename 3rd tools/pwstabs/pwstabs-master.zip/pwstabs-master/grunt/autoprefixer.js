module.exports = {
    
    dist: {
        options: {
            browsers: ['last 20 versions', 'Firefox > 10', 'Chrome > 20']
        },
        files: {
            'assets/jquery.pwstabs.css': 'assets/jquery.pwstabs.css'
        }
    }
    
};